name =  input ("Enter your Name: ") 
surname = input ("Enter your first Surname: ")
sum = 0

for i in name:
    print (i + " =", end = " ")
    print (ord(i))
    sum += ord(i)

print("\n")

for i in surname:
    print (i + " =", end = " ")
    print(ord(i))
    sum += ord(i)

print("The sum of ASCII characters are: ", sum)
problemNr = (sum % 4) + 1
print("You have problem ", problemNr)
    
    
    
