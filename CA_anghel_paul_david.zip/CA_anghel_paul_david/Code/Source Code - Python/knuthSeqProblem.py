from search import Problem
import math

# Basic function that computes the factorial of a number n
def factorialOfNumber(n):
    if n == 0:
        return 1
    else:
        return n * factorialOfNumber(n-1)


class KnuthSequence(Problem):
    
    def result(self, state, action):        
        return action

    def value(self, state):
        pass

    # Initalize components
    def __init__(self, initial, goal):
        self.goal = goal
        self.initial = initial
        self.visited_states = []
        Problem.__init__(self, self.initial, self.goal)

    def __repr__(self):
        return "< State (%s, %s) >" % (self.initial, self.goal)

    # It verifies if the goal state is reached
    def goal_test(self, state):
        return state == self.goal

    # Function that stores all the actions in a list[tuple]
    def actions(self, cur_state):
            actions = []

            self.visited_states.append(cur_state)
                   
           # Square root action
            new_state = (math.sqrt(cur_state[0]), 0)
            if cur_state[0] != new_state[0]:
                actions.append(new_state)
           
           # Floor action
            new_state = (math.floor(cur_state[0]), 0)
            if cur_state[0] != new_state[0]:
                actions.append(new_state)

           # Factorial action
            if cur_state[0] == math.floor(cur_state[0]) and cur_state[0] < 100:
                new_state = (factorialOfNumber(cur_state[0]), 0)
            if cur_state[0] != new_state[0]:
                actions.append(new_state)

            return actions
