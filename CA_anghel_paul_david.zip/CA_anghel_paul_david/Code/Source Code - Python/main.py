from search import *
from knuthSeqProblem import *
import time

def main():

    # Initialize time in the begining
    start_time = time.time()
    print("\tProblem 2: The Knuth Sequence")

    # Reading the starting number and goal number from user input
    startNr = int (input("Input the starting number: "))
    goalNr = int (input("Input the goal number: "))    
    knuth_problem = KnuthSequence((startNr, 0), (goalNr, 0))

    # Search the solution using Breadth first tree search from search.py
    path = breadth_first_tree_search(knuth_problem).solution()
    
    # Display the path and the number of steps required to obtain the solution
    print(path, '\n')
    print("Solution found in ", len(path), "steps\n")

    # We compute the time needed for the program to reach the goal state (current time - starting time = elapsed time) 
    print("Program executed in %s seconds. " % (time.time() - start_time))

if __name__ == "__main__":
    main()
