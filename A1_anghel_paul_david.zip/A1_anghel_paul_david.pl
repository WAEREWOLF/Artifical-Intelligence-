% 1) 

direct_train(craiova, bucharest).
direct_train(sibiu, craiova).
direct_train(deva, sibiu).
direct_train(brasov, deva).
direct_train(pitesti, brasov).
direct_train(ploiesti, pitesti).
direct_train(constanta, ploiesti).

/* Predicate that verify recursively if 2 cities have a "direct train", with direct link or through other cities.
 * 
 * rute_is_possible(+X : string, +Y : string).
 *
 * @param X is the starting city
 * @param Y is the destination city
*/
rute_is_possible(X,Y) :- direct_train(X,Y). %base case
rute_is_possible(X,Y) :- direct_train(X, A), rute_is_possible(A, Y). %recursive case

% 2)
translate(unu, one).
translate(doi, two).
translate(trei, three).
translate(patru, four).
translate(cinci, five).
translate(sase, six).
translate(sapte, seven).
translate(opt, eight).
translate(noua, nine).

/* Predicate that finds the corresponding romanian numbers in a given list, translating them in english, using the given Knowledge Base
 * 
 * translate_list(+List1 : list, ?List2 : list).
 * 
 * @param [HeadRo|TailRo] is the given list with romanian numbers, where "HeadRo" is the head of the list, and "TailRo" is the rest of the list
 * @param [HeadEn|TailEn] is the output list with english numbers, where ""HeadEn" is the head of the list, and "TailEn" is the rest of the list
*/ 
 

translate_list([],[]). %base case                  
translate_list([HeadRo|TailRo],[HeadEn|TailEn]) :- translate(HeadRo,HeadEn),  translate_list(TailRo,TailEn). %recursive case

% 3)

/* Predicate that duplicates elements of a given list N times 
 * 
 * duplicate(+List1 : list, +integer, ?List2 : list).
 * 
 * @param [H|T] is the given list with "H" representing the head and "T" the rest of the list
 * @param N is a given number that represents the times that the numbers in the given list must duplicate
 * @param [H|T2] is the output list with "H" the head and "T2" the remaining elements of the list
 * @param Aux is an auxiliary variable that is a copy of "N"(to dont lose its value), and it counts how many duplications left
 * @param P is a temporary list that keeps the duplicated 'heads' N times 
 * @param Q is a temporary list that keeps the duplicated remaning elements N times 
 * 
 * append(P,Q,R) is a predefined function in Prolog, where "R" is a list that represents the concatenation of list P and Q
*/
duplicate([LastNumber], 1, [LastNumber]).  % finish case, when all the numbers were duplicated, and  N reaches the end value: 1 (because it is indexed with 1)  
duplicate([H], N, [H|T2]) :-  Aux is N - 1,  Aux > 0,  duplicate([H], Aux, T2). 
duplicate([H|T], N, R) :-  duplicate([H], N, P), duplicate(T, N, Q), append(P, Q, R).

% 4)

/* Predicate that insert a  number in a given list at a certain position
 * 
 * insert_at_position(+GivenList : list, +Number : integer, +Position : integer, ?List : list).
 * 
 * @param List is the output list 
 * @param Number is the number that will be inserted
 * @param Position is the position where the number will be inserted
 * @param [Head|Tail1] is the given list with head and tail
 * @param [Head|Tail2] is the output list with head and tail
 * @param Aux it is used to copy the position, to help iterate through the given list reaching the wanted position
 
*/

insert_at_position(GivenList,Number,1,[Number|GivenList]). % base case
insert_at_position([Head|Tail1], Number, Position, [Head|Tail2]) :- Aux is Position - 1, insert_at_position(Tail1, Number, Aux, Tail2). % recursive case


% 5)

/* Predicate that generate a list with consecutive integers within a given range
 * 
 * generate_list_in_range(?List : list, +Start : integer, +End : integer).
 *  
 * @param [Start|T] represents the output list initialized with the first element the start number of the interval, and "T" represents the remaing elements of the list (tail)
 * @param Start is the left constraint of the given range, also the first element of the created list
 * @param End is the right constraint of the given range, also the last element of the created list
 * @param Iterator it is used to close the 'gap' between "start" and "end", iterating through the list
 * 
*/


generate_list_in_range([LastElement],LastElement,LastElement).
generate_list_in_range([Start|T],Start,End) :- Start < End, Iterator is Start + 1, generate_list_in_range(T,Iterator,End).


