from search import *
from P1 import Pr1
from P2 import Pr2


def main():

    print("Problem 1")
    problema_p1 = Pr1((0,0), (2,0))
    path_p1 = breadth_first_graph_search(problema_p1).solution()
    print("Solution:")
    print(path_p1, '\n')

    print("Problem 2")
    problema_p2 = Pr2((1,2,3,4,5,6,7,8,9,10,11,12,13,0,14,15), (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0))
    path_p2 = astar_search(problema_p2).solution()
    print("Solution:")
    print(path_p2, '\n')


if __name__ == "__main__":
    main()
