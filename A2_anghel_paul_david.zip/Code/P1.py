from search import Problem

class Pr1(Problem):
    
    def result(self, state, action):
        """The result of going to a neighbor is just that neighbor."""
        return action

    def value(self, state):
        pass

    def __init__(self, initial, goal):
        self.goal = goal
        self.initial = initial
        self.visited_states = []
        Problem.__init__(self, self.initial, self.goal)

    def __repr__(self):
        return "< State (%s, %s) >" % (self.initial, self.goal)

    def goal_test(self, state):
        return state == self.goal 

    def actions(self, current_state):
        actions = []
        self.visited_states.append(current_state)        

        #FILL first jug (4l)
        new_state = (4, current_state[0])
        if current_state[0] < 4:
            actions.append(new_state)
            #print("Fill the 4l jug")

        #FILL second jug (3l)
        new_state = (current_state[0],3)
        if current_state[1] < 3:
            actions.append(new_state)
            #print("Fill the 3l jug")

        #EMPTY first jug (4l)
        new_state=(0,current_state[0])
        if current_state[1] > 0:
            actions.append(new_state)
            #print("Empty the 4l jug")

        #EMPTY second jug (3l)
        new_state=(current_state[0], 0)
        if current_state[1] > 0:
            actions.append(new_state)
            #print("Empty the 3l jug")

        #POUR from 4l jug (firstJug) in to the 3l jug (secondJug)
        firstJug = current_state[0]
        secondJug = current_state[1]
        while firstJug > 0 and secondJug < 3: 
            secondJug += 1
            firstJug -= 1
        new_state = (firstJug, secondJug)
        if current_state[0] > 0 and current_state[1] < 3:
            actions.append(new_state)
            #print("Pour from 4l jug in to the 3l jug")
            
        #POUR from 3l jug in to the 4l jug
        firstJug = current_state[0]
        secondJug = current_state[1]

        while firstJug < 4 and secondJug > 0:
            secondJug -= 1
            firstJug += 1
        new_state = (firstJug, secondJug)
        if current_state[0] < 4 and current_state[1] > 0:
            actions.append(new_state)
            #print("Pour from 3l jug in to the 4l jug")        

        return actions




