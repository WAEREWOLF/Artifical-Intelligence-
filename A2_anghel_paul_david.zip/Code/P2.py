
from search import Problem
import math


class Pr2(Problem):
    """ The problem of sliding tiles numbered from 1 to 8 on a 3x3 board,
    where one of the squares is a blank. A state is represented as a 3x3 list,
    where element at index i,j represents the tile number (0 if it's an empty square) """

    def __init__(self, initial, goal):
        """ Define goal state and initialize a problem """

        self.goal = goal
        Problem.__init__(self, initial, goal)

    def find_blank_square(self, state):
        """Return the index of the blank square in a given state"""

        return state.index(0)

    def actions(self, state):
        """ Return the actions that can be executed in the given state.
        The result would be a list, since there are only four possible actions
        in any given state of the environment """

        possible_actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        index_blank_square = self.find_blank_square(state)

        # actions remove when necessary 
        if index_blank_square < 4 == 0:
            possible_actions.remove('UP')
        if index_blank_square > 11:
            possible_actions.remove('DOWN')
        if index_blank_square % 4 == 0:
            possible_actions.remove('LEFT')
        if index_blank_square %4 == 3:
            possible_actions.remove("RIGHT")


        return possible_actions

    def result(self, state, action):
        """ Given state and action, return a new state that is the result of the action.
        Action is assumed to be a valid action in the state """

        # blank is the index of the blank square
        blank = self.find_blank_square(state)
        new_state = list(state)

        delta = {'UP': -4, 'DOWN': 4, 'LEFT': -1, 'RIGHT': 1}
        neighbor = blank + delta[action]
        new_state[blank], new_state[neighbor] = new_state[neighbor], new_state[blank]

        return tuple(new_state)

    def goal_test(self, state):
        """ Given a state, return True if state is a goal state or False, otherwise """

        return state == self.goal

    def check_solvability(self, state):
        """ Checks if the given state is solvable """

        inversion = 0
        for i in range(len(state)):
            for j in range(i, len(state)):
                if state[i] > state[j] != 0:
                    inversion += 1

        return inversion % 2 == 0
    
    #Given heuristic
   # def h(self, node):
       #return sum(s != g for (s, g) in zip(node.state, self.goal))

    # Manhatan heuristic
   # def h(self, node):        
    #    return sum(abs(s / 4 - g / 4) + abs(s % 4 - g % 4) for (s,g) in zip(node.state, self.goal))

    #Euclidian heuristic
    def h(self, node):
        return sum(math.sqrt(pow(abs(s / 4 - g / 4),2) + pow(abs(s % 4 - g % 4),2)) for (s,g) in zip(node.state, self.goal))

    